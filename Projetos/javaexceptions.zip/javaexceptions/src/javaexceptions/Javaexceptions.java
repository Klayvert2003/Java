package javaexceptions;

import java.util.InputMismatchException;
import java.util.Scanner;

/*
 * @author Klayvert
*/

public class Javaexceptions {

    
    public static void main(String[] args) {
        
        int x;
        int y;
        int resultado;
        String s;
        Scanner sc = new Scanner(System.in);
        
        //Bloco TRY
        try{
            System.out.println("Digite um numero: ");
            x = sc.nextInt();
            y = sc.nextInt();
            resultado = x / y;
            System.out.println("Digite uma letra: ");
            s = sc.next();
            //Tratar SOMENTE erros de input
            System.out.println("O resultado e: " + resultado);
        /*catch(InputMismatchException e){
            sc = null;
            sc = new Scanner(System.in);
            System.out.println("Digite novamente: ");
            x = sc.nextInt();
            //System.out.println("Mensagem de erro: "+e.getMessage());
            
            //Valor que foi digitado incorretamente
        }catch(NumberFormatException e){
            System.out.println("Digitou o formato incorreto!!!");
            
        //Trata divisões (inteiras) por 0
        }catch(ArithmeticException e){
            System.out.println("Você dividiu por 0");*/
        }catch(InputMismatchException | ArithmeticException e){
            System.out.println("Tratando o erro!!!"+e.getMessage());
        }
        
        
        
        
        /*
        finally{
            System.out.println("Digite uma letra: ");
            s = sc.next();
        }
        System.out.println("OK");
  } */
}
}
